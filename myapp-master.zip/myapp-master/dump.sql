CREATE TABLE users (
  "id"   SERIAL PRIMARY KEY,
  "name" VARCHAR
);

INSERT INTO users ("name") VALUES
  ('Slim'),
  ('Reham'),
  ('Youssef'),
  ('Hesham'),
  ('Mark');
